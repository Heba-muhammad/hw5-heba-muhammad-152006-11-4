﻿namespace teacherattendaceDB1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.Label dateLabel;
            System.Windows.Forms.Label start_timeLabel;
            System.Windows.Forms.Label leave_timeLabel;
            System.Windows.Forms.Label course_nameLabel;
            System.Windows.Forms.Label teacher_nameLabel;
            System.Windows.Forms.Label room_nameLabel;
            System.Windows.Forms.Label attendace_noLabel;
            this.label6 = new System.Windows.Forms.Label();
            this.coursesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teacherAttendanceDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teacherAttendanceDataSet1 = new teacherattendaceDB1.TeacherAttendanceDataSet1();
            this.teachersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.roomsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.attendacesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.attendacesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teacherAttendanceDataSet = new teacherattendaceDB1.TeacherAttendanceDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.attendacesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.attendacesDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.attendacesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.attendacesTableAdapter = new teacherattendaceDB1.TeacherAttendanceDataSetTableAdapters.attendacesTableAdapter();
            this.tableAdapterManager = new teacherattendaceDB1.TeacherAttendanceDataSetTableAdapters.TableAdapterManager();
            this.attendacesTableAdapter1 = new teacherattendaceDB1.TeacherAttendanceDataSet1TableAdapters.attendacesTableAdapter();
            this.coursesTableAdapter = new teacherattendaceDB1.TeacherAttendanceDataSet1TableAdapters.coursesTableAdapter();
            this.teachersTableAdapter = new teacherattendaceDB1.TeacherAttendanceDataSet1TableAdapters.teachersTableAdapter();
            this.roomsTableAdapter = new teacherattendaceDB1.TeacherAttendanceDataSet1TableAdapters.roomsTableAdapter();
            this.dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.start_timeTextBox = new System.Windows.Forms.TextBox();
            this.leave_timeTextBox = new System.Windows.Forms.TextBox();
            this.course_nameTextBox = new System.Windows.Forms.TextBox();
            this.teacher_nameTextBox = new System.Windows.Forms.TextBox();
            this.room_nameTextBox = new System.Windows.Forms.TextBox();
            this.attendace_noTextBox = new System.Windows.Forms.TextBox();
            this.coursesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.coursesTableAdapter1 = new teacherattendaceDB1.TeacherAttendanceDataSetTableAdapters.coursesTableAdapter();
            dateLabel = new System.Windows.Forms.Label();
            start_timeLabel = new System.Windows.Forms.Label();
            leave_timeLabel = new System.Windows.Forms.Label();
            course_nameLabel = new System.Windows.Forms.Label();
            teacher_nameLabel = new System.Windows.Forms.Label();
            room_nameLabel = new System.Windows.Forms.Label();
            attendace_noLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.coursesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAttendanceDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAttendanceDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teachersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendacesBindingNavigator)).BeginInit();
            this.attendacesBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendacesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAttendanceDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendacesDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendacesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coursesBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label6.Location = new System.Drawing.Point(152, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Leave Time";
            // 
            // coursesBindingSource
            // 
            this.coursesBindingSource.DataMember = "courses";
            this.coursesBindingSource.DataSource = this.teacherAttendanceDataSet1BindingSource;
            // 
            // teacherAttendanceDataSet1BindingSource
            // 
            this.teacherAttendanceDataSet1BindingSource.DataSource = this.teacherAttendanceDataSet1;
            this.teacherAttendanceDataSet1BindingSource.Position = 0;
            // 
            // teacherAttendanceDataSet1
            // 
            this.teacherAttendanceDataSet1.DataSetName = "TeacherAttendanceDataSet1";
            this.teacherAttendanceDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // teachersBindingSource
            // 
            this.teachersBindingSource.DataMember = "teachers";
            this.teachersBindingSource.DataSource = this.teacherAttendanceDataSet1BindingSource;
            // 
            // roomsBindingSource
            // 
            this.roomsBindingSource.DataMember = "rooms";
            this.roomsBindingSource.DataSource = this.teacherAttendanceDataSet1BindingSource;
            // 
            // attendacesBindingNavigator
            // 
            this.attendacesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.attendacesBindingNavigator.BindingSource = this.attendacesBindingSource;
            this.attendacesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.attendacesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.attendacesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.attendacesBindingNavigatorSaveItem});
            this.attendacesBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.attendacesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.attendacesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.attendacesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.attendacesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.attendacesBindingNavigator.Name = "attendacesBindingNavigator";
            this.attendacesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.attendacesBindingNavigator.Size = new System.Drawing.Size(1005, 25);
            this.attendacesBindingNavigator.TabIndex = 13;
            this.attendacesBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // attendacesBindingSource
            // 
            this.attendacesBindingSource.DataMember = "attendaces";
            this.attendacesBindingSource.DataSource = this.teacherAttendanceDataSet;
            // 
            // teacherAttendanceDataSet
            // 
            this.teacherAttendanceDataSet.DataSetName = "TeacherAttendanceDataSet";
            this.teacherAttendanceDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // attendacesBindingNavigatorSaveItem
            // 
            this.attendacesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.attendacesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("attendacesBindingNavigatorSaveItem.Image")));
            this.attendacesBindingNavigatorSaveItem.Name = "attendacesBindingNavigatorSaveItem";
            this.attendacesBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.attendacesBindingNavigatorSaveItem.Text = "Save Data";
            this.attendacesBindingNavigatorSaveItem.Click += new System.EventHandler(this.attendacesBindingNavigatorSaveItem_Click);
            // 
            // attendacesDataGridView
            // 
            this.attendacesDataGridView.AutoGenerateColumns = false;
            this.attendacesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.attendacesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.attendacesDataGridView.DataSource = this.attendacesBindingSource1;
            this.attendacesDataGridView.Location = new System.Drawing.Point(317, 62);
            this.attendacesDataGridView.Name = "attendacesDataGridView";
            this.attendacesDataGridView.Size = new System.Drawing.Size(643, 220);
            this.attendacesDataGridView.TabIndex = 14;
            this.attendacesDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.attendacesDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "date";
            this.dataGridViewTextBoxColumn1.HeaderText = "date";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "start_time";
            this.dataGridViewTextBoxColumn2.HeaderText = "start_time";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "leave_time";
            this.dataGridViewTextBoxColumn3.HeaderText = "leave_time";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "course_name";
            this.dataGridViewTextBoxColumn4.HeaderText = "course_name";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "teacher_name";
            this.dataGridViewTextBoxColumn5.HeaderText = "teacher_name";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "room_name";
            this.dataGridViewTextBoxColumn6.HeaderText = "room_name";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // attendacesBindingSource1
            // 
            this.attendacesBindingSource1.DataMember = "attendaces";
            this.attendacesBindingSource1.DataSource = this.teacherAttendanceDataSet1BindingSource;
            // 
            // attendacesTableAdapter
            // 
            this.attendacesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.attendacesTableAdapter = this.attendacesTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.coursesTableAdapter = null;
            this.tableAdapterManager.roomsTableAdapter = null;
            this.tableAdapterManager.teachersTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = teacherattendaceDB1.TeacherAttendanceDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // attendacesTableAdapter1
            // 
            this.attendacesTableAdapter1.ClearBeforeFill = true;
            // 
            // coursesTableAdapter
            // 
            this.coursesTableAdapter.ClearBeforeFill = true;
            // 
            // teachersTableAdapter
            // 
            this.teachersTableAdapter.ClearBeforeFill = true;
            // 
            // roomsTableAdapter
            // 
            this.roomsTableAdapter.ClearBeforeFill = true;
            // 
            // dateLabel
            // 
            dateLabel.AutoSize = true;
            dateLabel.Location = new System.Drawing.Point(28, 43);
            dateLabel.Name = "dateLabel";
            dateLabel.Size = new System.Drawing.Size(33, 13);
            dateLabel.TabIndex = 14;
            dateLabel.Text = "date:";
            dateLabel.Click += new System.EventHandler(this.dateLabel_Click);
            // 
            // dateDateTimePicker
            // 
            this.dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.attendacesBindingSource, "date", true));
            this.dateDateTimePicker.Location = new System.Drawing.Point(111, 39);
            this.dateDateTimePicker.Name = "dateDateTimePicker";
            this.dateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateDateTimePicker.TabIndex = 15;
            this.dateDateTimePicker.ValueChanged += new System.EventHandler(this.dateDateTimePicker_ValueChanged);
            // 
            // start_timeLabel
            // 
            start_timeLabel.AutoSize = true;
            start_timeLabel.Location = new System.Drawing.Point(28, 68);
            start_timeLabel.Name = "start_timeLabel";
            start_timeLabel.Size = new System.Drawing.Size(57, 13);
            start_timeLabel.TabIndex = 16;
            start_timeLabel.Text = "start time:";
            start_timeLabel.Click += new System.EventHandler(this.start_timeLabel_Click);
            // 
            // start_timeTextBox
            // 
            this.start_timeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.attendacesBindingSource, "start_time", true));
            this.start_timeTextBox.Location = new System.Drawing.Point(111, 65);
            this.start_timeTextBox.Name = "start_timeTextBox";
            this.start_timeTextBox.Size = new System.Drawing.Size(200, 20);
            this.start_timeTextBox.TabIndex = 17;
            this.start_timeTextBox.TextChanged += new System.EventHandler(this.start_timeTextBox_TextChanged);
            // 
            // leave_timeLabel
            // 
            leave_timeLabel.AutoSize = true;
            leave_timeLabel.Location = new System.Drawing.Point(28, 94);
            leave_timeLabel.Name = "leave_timeLabel";
            leave_timeLabel.Size = new System.Drawing.Size(60, 13);
            leave_timeLabel.TabIndex = 18;
            leave_timeLabel.Text = "leave time:";
            leave_timeLabel.Click += new System.EventHandler(this.leave_timeLabel_Click);
            // 
            // leave_timeTextBox
            // 
            this.leave_timeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.attendacesBindingSource, "leave_time", true));
            this.leave_timeTextBox.Location = new System.Drawing.Point(111, 91);
            this.leave_timeTextBox.Name = "leave_timeTextBox";
            this.leave_timeTextBox.Size = new System.Drawing.Size(200, 20);
            this.leave_timeTextBox.TabIndex = 19;
            this.leave_timeTextBox.TextChanged += new System.EventHandler(this.leave_timeTextBox_TextChanged);
            // 
            // course_nameLabel
            // 
            course_nameLabel.AutoSize = true;
            course_nameLabel.Location = new System.Drawing.Point(25, 118);
            course_nameLabel.Name = "course_nameLabel";
            course_nameLabel.Size = new System.Drawing.Size(72, 13);
            course_nameLabel.TabIndex = 20;
            course_nameLabel.Text = "course name:";
            course_nameLabel.Click += new System.EventHandler(this.course_nameLabel_Click);
            // 
            // course_nameTextBox
            // 
            this.course_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.attendacesBindingSource, "course_name", true));
            this.course_nameTextBox.Location = new System.Drawing.Point(111, 117);
            this.course_nameTextBox.Name = "course_nameTextBox";
            this.course_nameTextBox.Size = new System.Drawing.Size(200, 20);
            this.course_nameTextBox.TabIndex = 21;
            this.course_nameTextBox.TextChanged += new System.EventHandler(this.course_nameTextBox_TextChanged);
            // 
            // teacher_nameLabel
            // 
            teacher_nameLabel.AutoSize = true;
            teacher_nameLabel.Location = new System.Drawing.Point(23, 143);
            teacher_nameLabel.Name = "teacher_nameLabel";
            teacher_nameLabel.Size = new System.Drawing.Size(77, 13);
            teacher_nameLabel.TabIndex = 22;
            teacher_nameLabel.Text = "teacher name:";
            teacher_nameLabel.Click += new System.EventHandler(this.teacher_nameLabel_Click);
            // 
            // teacher_nameTextBox
            // 
            this.teacher_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.attendacesBindingSource, "teacher_name", true));
            this.teacher_nameTextBox.Location = new System.Drawing.Point(111, 143);
            this.teacher_nameTextBox.Name = "teacher_nameTextBox";
            this.teacher_nameTextBox.Size = new System.Drawing.Size(200, 20);
            this.teacher_nameTextBox.TabIndex = 23;
            this.teacher_nameTextBox.TextChanged += new System.EventHandler(this.teacher_nameTextBox_TextChanged);
            // 
            // room_nameLabel
            // 
            room_nameLabel.AutoSize = true;
            room_nameLabel.Location = new System.Drawing.Point(24, 171);
            room_nameLabel.Name = "room_nameLabel";
            room_nameLabel.Size = new System.Drawing.Size(64, 13);
            room_nameLabel.TabIndex = 24;
            room_nameLabel.Text = "room name:";
            room_nameLabel.Click += new System.EventHandler(this.room_nameLabel_Click);
            // 
            // room_nameTextBox
            // 
            this.room_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.attendacesBindingSource, "room_name", true));
            this.room_nameTextBox.Location = new System.Drawing.Point(111, 169);
            this.room_nameTextBox.Name = "room_nameTextBox";
            this.room_nameTextBox.Size = new System.Drawing.Size(200, 20);
            this.room_nameTextBox.TabIndex = 25;
            this.room_nameTextBox.TextChanged += new System.EventHandler(this.room_nameTextBox_TextChanged);
            // 
            // attendace_noLabel
            // 
            attendace_noLabel.AutoSize = true;
            attendace_noLabel.Location = new System.Drawing.Point(22, 197);
            attendace_noLabel.Name = "attendace_noLabel";
            attendace_noLabel.Size = new System.Drawing.Size(75, 13);
            attendace_noLabel.TabIndex = 26;
            attendace_noLabel.Text = "attendace no:";
            attendace_noLabel.Click += new System.EventHandler(this.attendace_noLabel_Click);
            // 
            // attendace_noTextBox
            // 
            this.attendace_noTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.attendacesBindingSource, "attendace_no", true));
            this.attendace_noTextBox.Location = new System.Drawing.Point(111, 195);
            this.attendace_noTextBox.Name = "attendace_noTextBox";
            this.attendace_noTextBox.Size = new System.Drawing.Size(200, 20);
            this.attendace_noTextBox.TabIndex = 27;
            this.attendace_noTextBox.TextChanged += new System.EventHandler(this.attendace_noTextBox_TextChanged);
            // 
            // coursesBindingSource1
            // 
            this.coursesBindingSource1.DataMember = "courses";
            this.coursesBindingSource1.DataSource = this.teacherAttendanceDataSet;
            // 
            // coursesTableAdapter1
            // 
            this.coursesTableAdapter1.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 395);
            this.Controls.Add(dateLabel);
            this.Controls.Add(this.dateDateTimePicker);
            this.Controls.Add(start_timeLabel);
            this.Controls.Add(this.start_timeTextBox);
            this.Controls.Add(leave_timeLabel);
            this.Controls.Add(this.leave_timeTextBox);
            this.Controls.Add(course_nameLabel);
            this.Controls.Add(this.course_nameTextBox);
            this.Controls.Add(teacher_nameLabel);
            this.Controls.Add(this.teacher_nameTextBox);
            this.Controls.Add(room_nameLabel);
            this.Controls.Add(this.room_nameTextBox);
            this.Controls.Add(attendace_noLabel);
            this.Controls.Add(this.attendace_noTextBox);
            this.Controls.Add(this.attendacesDataGridView);
            this.Controls.Add(this.attendacesBindingNavigator);
            this.Controls.Add(this.label6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.coursesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAttendanceDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAttendanceDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teachersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendacesBindingNavigator)).EndInit();
            this.attendacesBindingNavigator.ResumeLayout(false);
            this.attendacesBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendacesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAttendanceDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendacesDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendacesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coursesBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private TeacherAttendanceDataSet teacherAttendanceDataSet;
        private System.Windows.Forms.BindingSource attendacesBindingSource;
        private TeacherAttendanceDataSetTableAdapters.attendacesTableAdapter attendacesTableAdapter;
        private TeacherAttendanceDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator attendacesBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton attendacesBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView attendacesDataGridView;
        private System.Windows.Forms.BindingSource teacherAttendanceDataSet1BindingSource;
        private TeacherAttendanceDataSet1 teacherAttendanceDataSet1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.BindingSource attendacesBindingSource1;
        private TeacherAttendanceDataSet1TableAdapters.attendacesTableAdapter attendacesTableAdapter1;
        private System.Windows.Forms.BindingSource coursesBindingSource;
        private TeacherAttendanceDataSet1TableAdapters.coursesTableAdapter coursesTableAdapter;
        private System.Windows.Forms.BindingSource teachersBindingSource;
        private TeacherAttendanceDataSet1TableAdapters.teachersTableAdapter teachersTableAdapter;
        private System.Windows.Forms.BindingSource roomsBindingSource;
        private TeacherAttendanceDataSet1TableAdapters.roomsTableAdapter roomsTableAdapter;
        private System.Windows.Forms.DateTimePicker dateDateTimePicker;
        private System.Windows.Forms.TextBox start_timeTextBox;
        private System.Windows.Forms.TextBox leave_timeTextBox;
        private System.Windows.Forms.TextBox course_nameTextBox;
        private System.Windows.Forms.TextBox teacher_nameTextBox;
        private System.Windows.Forms.TextBox room_nameTextBox;
        private System.Windows.Forms.TextBox attendace_noTextBox;
        private System.Windows.Forms.BindingSource coursesBindingSource1;
        private TeacherAttendanceDataSetTableAdapters.coursesTableAdapter coursesTableAdapter1;
    }
}

