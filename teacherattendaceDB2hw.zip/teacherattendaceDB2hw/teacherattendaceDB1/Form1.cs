﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace teacherattendaceDB1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void attendacesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.attendacesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.teacherAttendanceDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet.courses' table. You can move, or remove it, as needed.
            this.coursesTableAdapter1.Fill(this.teacherAttendanceDataSet.courses);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet1.rooms' table. You can move, or remove it, as needed.
            this.roomsTableAdapter.Fill(this.teacherAttendanceDataSet1.rooms);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet1.teachers' table. You can move, or remove it, as needed.
            this.teachersTableAdapter.Fill(this.teacherAttendanceDataSet1.teachers);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet1.courses' table. You can move, or remove it, as needed.
            this.coursesTableAdapter.Fill(this.teacherAttendanceDataSet1.courses);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet1.attendaces' table. You can move, or remove it, as needed.
            this.attendacesTableAdapter1.Fill(this.teacherAttendanceDataSet1.attendaces);
            // TODO: This line of code loads data into the 'teacherAttendanceDataSet.attendaces' table. You can move, or remove it, as needed.
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
           

        }

        private void attendacesDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void dateLabel_Click(object sender, EventArgs e)
        {

        }

        private void dateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void start_timeLabel_Click(object sender, EventArgs e)
        {

        }

        private void start_timeTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void leave_timeLabel_Click(object sender, EventArgs e)
        {

        }

        private void leave_timeTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void course_nameLabel_Click(object sender, EventArgs e)
        {

        }

        private void course_nameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void teacher_nameLabel_Click(object sender, EventArgs e)
        {

        }

        private void teacher_nameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void room_nameLabel_Click(object sender, EventArgs e)
        {

        }

        private void room_nameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void attendace_noLabel_Click(object sender, EventArgs e)
        {

        }

        private void attendace_noTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
                    }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {

        }
        
    }
}
